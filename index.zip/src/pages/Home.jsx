import React from 'react'
export default function Home(){
  return (
    <div>
      <h2>Home</h2>
      <div className="card">
        <p>Welcome to the Admin Panel. Use the menu to navigate.</p>
      </div>
    </div>
  )
}
